# CONTROLEX – Proyecto Profesional Informático (WallRed)
Aplicación web ASP.NET Core MVC (C# 14, .NET 10) con SQL Server 2025 Express. Estado: Fase 0 + Login.

## Puesta en marcha
```
cd src/Controlex.Web
dotnet user-secrets set "ConnectionStrings:Controlex" "Server=.\SQLEXPRESS;Database=CONTROLEX_DB;Trusted_Connection=True;TrustServerCertificate=True"
dotnet run -- hash "TuClaveInicial1!"      # copiar el hash a usuarios.contrasena_hash del usuario mhernandez
dotnet run
```
